import './App.css';
import Badge from './Badge';
import IdentityButton from './IdentityButton';
import Wallets from './Wallets';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <Badge /> */}
        {/* <IdentityButton /> */}
        <Wallets />
      </header>
    </div>
  );
}

export default App;
