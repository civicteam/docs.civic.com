import React, { useMemo } from 'react';
import { PublicKey, clusterApiUrl } from '@solana/web3.js';
import { GatewayProvider, useGateway, GatewayStatus } from '@civic/solana-gateway-react';
import { ConnectionProvider, useWallet, WalletProvider } from '@solana/wallet-adapter-react';
import { getPhantomWallet, getSolletWallet } from '@solana/wallet-adapter-wallets';
import { WalletAdapterNetwork } from "@solana/wallet-adapter-base";

import {
  WalletModalProvider,
  WalletDisconnectButton,
  WalletMultiButton
} from '@solana/wallet-adapter-react-ui';

// Default styles that can be overridden by your app
require('@solana/wallet-adapter-react-ui/styles.css');

const env = {
  prod: {
    gatekeeperNetwork: new PublicKey('ni1jXzPTq1yTqo67tUmVgnp22b1qGAAZCtPmHtskqYG'),
  },
  test: {
    gatekeeperNetwork: new PublicKey('tniC2HX5yg2yDjMQEcUo1bHa44x9YdZVSqyKox21SDz'),
    clusterUrl: 'https://api.devnet.solana.com',
    stage: 'preprod',
  }
};

function RequestGatewayToken() {
  const { gatewayStatus,requestGatewayToken, gatewayToken } = useGateway();
  return (
      <>
          <div>Wallet adapter connected</div>
          <div>Gateway status: {GatewayStatus[gatewayStatus]}</div>
          <br />
          <button type='submit' onClick={requestGatewayToken}>Requests Gateway Token</button>
          <br />
          <div>Gateway token: {gatewayToken?.publicKey.toBase58()}</div>
      </>
  )
};

function Gateway() {
  const wallet = useWallet();
  const { publicKey } = wallet;
  const { gatekeeperNetwork, stage, clusterUrl } = env.prod;
  return (
    <GatewayProvider 
      wallet={wallet} 
      gatekeeperNetwork={gatekeeperNetwork}
      stage={stage}
      clusterUrl={clusterUrl}>
        { publicKey && <RequestGatewayToken /> }
    </GatewayProvider>
  )
}

function Wallets () {
  const network = WalletAdapterNetwork.Devnet;
  const endpoint = useMemo(() => clusterApiUrl(network), [network]);
  const wallets = useMemo(
    () => [
      getPhantomWallet(),
      getSolletWallet({ network }),
    ],
    [network]
  );

  return (
    <ConnectionProvider endpoint={endpoint}>
      <WalletProvider wallets={wallets} autoConnect>
        <WalletModalProvider>
          <WalletMultiButton />
          <br />
          <WalletDisconnectButton />
          <br />
          <Gateway />
        </WalletModalProvider>
      </WalletProvider>
    </ConnectionProvider>
  );
};

export default Wallets;